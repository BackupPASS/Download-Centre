const display = document.getElementById('display');

let current = '';
let lastResult = false;

function updateDisplay(value) {
  display.value = value || '0';
}

function isOperator(char) {
  return ['+', '-', '*', '/'].includes(char);
}

// safer evaluation than eval (still simple but controlled)
function calculate(expr) {
  try {
    // only allow valid characters
    if (!/^[0-9+\-*/().\s]+$/.test(expr)) throw new Error('Invalid');

    // prevent empty parentheses like ()
    if (expr.includes('()')) throw new Error('Invalid');

    return Function(`"use strict"; return (${expr})`)();
  } catch {
    throw new Error('Invalid');
  }
}

function appendValue(value) {
  if (display.value === 'Error') current = '';

  // prevent double operators
  const lastChar = current.slice(-1);

  if (isOperator(value) && isOperator(lastChar)) {
    current = current.slice(0, -1) + value;
  } else {
    current += value;
  }

  lastResult = false;
  updateDisplay(current);
}

document.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => {
    const value = btn.dataset.value;
    const action = btn.dataset.action;

    if (value) {
      appendValue(value);
      return;
    }

    if (action === 'clear') {
      current = '';
      lastResult = false;
      updateDisplay('0');
      return;
    }

    if (action === 'delete') {
      if (display.value === 'Error') {
        current = '';
        updateDisplay('0');
        return;
      }

      current = current.slice(0, -1);
      updateDisplay(current);
      return;
    }

    if (action === 'equals') {
      try {
        const result = calculate(current);
        current = String(result);
        lastResult = true;
        updateDisplay(current);
      } catch {
        current = '';
        updateDisplay('Error');
      }
    }
  });
});

// Keyboard support (huge quality upgrade for Vinti)
document.addEventListener('keydown', (e) => {
  const key = e.key;

  if (!isNaN(key) || ['+', '-', '*', '/', '.', '(', ')'].includes(key)) {
    appendValue(key);
  }

  if (key === 'Enter') {
    e.preventDefault();
    document.querySelector('[data-action="equals"]').click();
  }

  if (key === 'Backspace') {
    document.querySelector('[data-action="delete"]').click();
  }

  if (key === 'Escape') {
    document.querySelector('[data-action="clear"]').click();
  }
});