const display = document.getElementById('display');
let current = '';

function updateDisplay(value) {
  display.value = value || '0';
}

document.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => {
    const value = btn.dataset.value;
    const action = btn.dataset.action;

    if (value) {
      current += value;
      updateDisplay(current);
      return;
    }

    if (action === 'clear') {
      current = '';
      updateDisplay('0');
      return;
    }

    if (action === 'delete') {
      current = current.slice(0, -1);
      updateDisplay(current);
      return;
    }

    if (action === 'equals') {
      try {
        // Safe basic math only
        if (!/^[0-9+\-*/.() ]+$/.test(current)) {
          throw new Error('Invalid input');
        }

        current = String(eval(current));
        updateDisplay(current);
      } catch {
        current = '';
        updateDisplay('Error');
      }
    }
  });
});
