const note = document.getElementById('note');
const saveBtn = document.getElementById('save');
const clearBtn = document.getElementById('clear');
const status = document.getElementById('status');

const STORAGE_KEY = 'vinti-notes-content';

note.value = localStorage.getItem(STORAGE_KEY) || '';

saveBtn.addEventListener('click', () => {
  localStorage.setItem(STORAGE_KEY, note.value);
  status.textContent = 'Saved locally';
  setTimeout(() => (status.textContent = ''), 1500);
});

clearBtn.addEventListener('click', () => {
  if (!note.value) return;
  if (!confirm('Clear all notes?')) return;

  note.value = '';
  localStorage.removeItem(STORAGE_KEY);
  status.textContent = 'Cleared';
  setTimeout(() => (status.textContent = ''), 1500);
});
