const STORAGE_KEY = 'vinti-notes-v2';

let data = loadData();

const list = document.getElementById('note-list');
const editor = document.getElementById('editor');
const titleEl = document.getElementById('note-title');
const status = document.getElementById('status');

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { notes: [], activeId: null };
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed.notes)) throw new Error();
    return parsed;
  } catch {
    return { notes: [], activeId: null };
  }
}

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function setStatus(text) {
  status.textContent = text;
  if (text) setTimeout(() => (status.textContent = ''), 1200);
}


function renderList() {
  list.innerHTML = '';

  if (data.notes.length === 0) {
    const empty = document.createElement('div');
    empty.style.color = '#b9c1d5';
    empty.style.fontSize = '12px';
    empty.style.padding = '6px 10px';
    empty.textContent = 'No notes yet';
    list.appendChild(empty);
    return;
  }

  data.notes.forEach(note => {
    const btn = document.createElement('button');
    btn.textContent = note.title || 'Untitled';
    if (note.id === data.activeId) btn.classList.add('active');
    btn.onclick = () => openNote(note.id);
    list.appendChild(btn);
  });
}

function renderEditor(note) {
  if (!note) {
    editor.value = '';
    editor.disabled = true;
    titleEl.textContent = 'Untitled';
    return;
  }

  editor.disabled = false;
  editor.value = note.content || '';
  titleEl.textContent = note.title || 'Untitled';
}


function openNote(id) {
  const note = data.notes.find(n => n.id === id);
  if (!note) return;

  data.activeId = id;
  persist();
  renderList();
  renderEditor(note);
}

document.getElementById('new-note').onclick = () => {
  const id = Date.now().toString();
  const note = {
    id,
    title: 'New note',
    content: '',
    updated: Date.now()
  };

  data.notes.unshift(note);
  data.activeId = id;

  persist();
  renderList();
  renderEditor(note);
  setStatus('New note created');
};

editor.addEventListener('input', () => {
  const note = data.notes.find(n => n.id === data.activeId);
  if (!note) return;

  note.content = editor.value;
  note.title =
    editor.value.split('\n')[0].trim().slice(0, 28) || 'Untitled';
  note.updated = Date.now();

  persist();
  renderList();
  titleEl.textContent = note.title;
});


document.getElementById('delete-note').onclick = () => {
  if (!data.activeId) return;
  if (!confirm('Delete this note?')) return;

  data.notes = data.notes.filter(n => n.id !== data.activeId);
  data.activeId = data.notes[0]?.id || null;

  persist();
  renderList();
  renderEditor(data.notes.find(n => n.id === data.activeId));
  setStatus('Note deleted');
};

document.getElementById('delete-all').onclick = () => {
  if (data.notes.length === 0) return;
  if (!confirm('Delete ALL notes?')) return;

  data = { notes: [], activeId: null };
  localStorage.removeItem(STORAGE_KEY);

  renderList();
  renderEditor(null);
  setStatus('All notes deleted');
};


renderList();

if (data.activeId) {
  const note = data.notes.find(n => n.id === data.activeId);
  renderEditor(note);
} else {
  renderEditor(null);
}
