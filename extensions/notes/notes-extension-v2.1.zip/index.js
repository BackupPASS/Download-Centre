const STORAGE_KEY = 'vinti-notes-v2.1';
let data = loadData();

let saveTimer = null;

const list = document.getElementById('note-list');
const editor = document.getElementById('editor');
const titleEl = document.getElementById('note-title');
const status = document.getElementById('status');

const searchInput = document.createElement('input');
searchInput.placeholder = 'Search notes...';
searchInput.style.cssText = `
  width:100%;
  padding:8px;
  border-radius:10px;
  border:none;
  outline:none;
  margin-bottom:10px;
  background:rgba(0,0,0,.35);
  color:white;
`;

list.parentElement.insertBefore(searchInput, list);

/* ---------- STORAGE ---------- */

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { notes: [], activeId: null };

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed.notes)) throw new Error();

    return parsed;
  } catch {
    return { notes: [], activeId: null };
  }
}

function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, 120);
}

/* ---------- CORE ---------- */

function setStatus(text) {
  status.textContent = text;
  if (text) setTimeout(() => (status.textContent = ''), 1200);
}

function getActiveNote() {
  return data.notes.find(n => n.id === data.activeId);
}

function sortNotes() {
  data.notes.sort((a, b) => (b.updated || 0) - (a.updated || 0));
}

/* ---------- RENDER LIST ---------- */

function renderList() {
  list.innerHTML = '';

  sortNotes();

  const q = searchInput.value.toLowerCase();

  const filtered = data.notes.filter(n =>
    (n.title || '').toLowerCase().includes(q) ||
    (n.content || '').toLowerCase().includes(q)
  );

  if (!filtered.length) {
    const empty = document.createElement('div');
    empty.textContent = data.notes.length ? 'No matches' : 'No notes yet';
    empty.style.cssText = 'color:rgba(185,193,213,.7);font-size:12px;padding:8px 10px;';
    list.appendChild(empty);
    return;
  }

  filtered.forEach(note => {
    const btn = document.createElement('button');
    btn.textContent = note.title || 'Untitled';

    if (note.id === data.activeId) btn.classList.add('active');

    btn.onclick = () => openNote(note.id);
    list.appendChild(btn);
  });
}

/* ---------- EDITOR ---------- */

function renderEditor(note) {
  if (!note) {
    editor.value = '';
    editor.disabled = true;
    titleEl.textContent = 'Untitled';
    return;
  }

  editor.disabled = false;
  editor.value = note.content || '';
  titleEl.textContent = note.title || 'Untitled';

  // IMPORTANT FIX: ensures typing always works after switching notes
  setTimeout(() => editor.focus(), 0);
}

function openNote(id) {
  const note = data.notes.find(n => n.id === id);
  if (!note) return;

  data.activeId = id;
  persist();
  renderList();
  renderEditor(note);
}

/* ---------- CREATE ---------- */

document.getElementById('new-note').onclick = () => {
  const id = crypto.randomUUID?.() || Date.now().toString();

  const note = {
    id,
    title: 'New note',
    content: '',
    updated: Date.now()
  };

  data.notes.unshift(note);
  data.activeId = id;

  persist();
  renderList();
  renderEditor(note);
  setStatus('Created');
};

/* ---------- SAVE ---------- */

editor.addEventListener('input', () => {
  const note = getActiveNote();
  if (!note) return;

  note.content = editor.value;
  note.title = editor.value.split('\n')[0].trim().slice(0, 28) || 'Untitled';
  note.updated = Date.now();

  persist();
  renderList();
  titleEl.textContent = note.title;
});

/* ---------- DELETE ---------- */

document.getElementById('delete-note').onclick = () => {
  if (!data.activeId) return;
  if (!confirm('Delete this note?')) return;

  data.notes = data.notes.filter(n => n.id !== data.activeId);
  data.activeId = data.notes[0]?.id || null;

  persist();
  renderList();
  renderEditor(getActiveNote());
  setStatus('Deleted');
};

/* ---------- DELETE ALL ---------- */

document.getElementById('delete-all').onclick = () => {
  if (!data.notes.length) return;
  if (!confirm('Delete ALL notes?')) return;

  data = { notes: [], activeId: null };
  localStorage.removeItem(STORAGE_KEY);

  renderList();
  renderEditor(null);
  setStatus('Cleared');
};

/* ---------- SEARCH ---------- */

searchInput.addEventListener('input', renderList);

/* ---------- FORMATTING (B / I / BULLET) ---------- */

function wrapSelection(before, after = before) {
  const start = editor.selectionStart;
  const end = editor.selectionEnd;
  const text = editor.value;

  const selected = text.slice(start, end);
  const newText =
    text.slice(0, start) +
    before + selected + after +
    text.slice(end);

  editor.value = newText;
  editor.focus();

  editor.selectionStart = start + before.length;
  editor.selectionEnd = end + before.length;

  editor.dispatchEvent(new Event('input'));
}

document.querySelector('[data-action="bold"]').onclick = () => {
  wrapSelection('**');
};

document.querySelector('[data-action="italic"]').onclick = () => {
  wrapSelection('_');
};

document.querySelector('[data-action="bullet"]').onclick = () => {
  const start = editor.selectionStart;
  const text = editor.value;

  const lineStart = text.lastIndexOf('\n', start - 1) + 1;

  editor.value =
    text.slice(0, lineStart) +
    '• ' +
    text.slice(lineStart);

  editor.focus();
  editor.dispatchEvent(new Event('input'));
};

/* ---------- INIT ---------- */

renderList();

if (data.activeId) {
  renderEditor(getActiveNote());
} else {
  renderEditor(null);
}